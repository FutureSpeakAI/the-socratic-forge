# The Socratic Forge

**A system for building software with AI agents through guided inquiry instead of instruction.**

Created by [Stephen C. Webster](https://www.linkedin.com/in/stephencwebster/) / [FutureSpeak.AI](https://futurespeak.ai)

---

## What Is This?

The Socratic Forge is a project planning methodology for AI coding agents — Claude Code, Google Antigravity, Replit, Cursor, Copilot Workspace, and any agentic coding tool that can read files and reason about them.

Instead of giving your agent step-by-step instructions, you give it carefully structured **questions** that force it to reason through the problem space, discover edge cases, and arrive at implementations that are better than any instruction set could specify.

The core insight: **an agent that follows instructions produces code that matches a spec. An agent that answers questions produces code that understands the problem.** The difference shows up in edge case handling, architecture decisions, and the quality of solutions the agent invents for problems you didn't anticipate.

This repo contains the complete methodology, ready-to-use templates, and a worked example you can study and adapt.

### Background

This method evolved from [The Socratic Paintbrush](https://www.linkedin.com/pulse/introducing-socratic-paintbrush-most-powerful-way-build-webster-be13c), a technique for using philosophical inquiry to plan software builds with AI. The Forge takes that technique and adds structure: six question types, a codebase grounding system, parallel track execution, safety gates, and an orchestration layer that can coordinate dozens of AI agent sessions across months of development.

The full story is in [The Socratic Forge: How I Taught My AI Agents to Think Before They Code](#) *(LinkedIn essay link)*.

The method was developed while building [Agent Friday](https://github.com/FutureSpeak-AI/agent-friday), an open-source AGI operating system — 9 tracks, 28 phases, 22,000+ lines of code, all built through Socratic inquiry.

---

## Quick Start (5 Minutes)

### 1. Copy the templates into your project

```bash
# From your project root
mkdir -p socratic-roadmaps
cp templates/00-SOCRATIC-METHODOLOGY.md socratic-roadmaps/
cp templates/01-GAP-MAP-TEMPLATE.md socratic-roadmaps/01-GAP-MAP.md
cp templates/PHASE-TEMPLATE.md socratic-roadmaps/phase-1-your-first-phase.md
```

### 2. Fill in the Gap Map

Open `socratic-roadmaps/01-GAP-MAP.md` and inventory your codebase. For every significant file: what it does, how many lines, what patterns it uses. If you're starting from scratch, just describe what you intend to build and what exists so far (even if that's nothing).

### 3. Write your first phase

Open the phase template and replace the placeholders with real Socratic questions about the first thing you want to build. Use the six question types (see below). Don't put answers in your questions.

### 4. Launch

**Claude Code:**
```
Read these three files in order, then begin implementation:
1. socratic-roadmaps/00-SOCRATIC-METHODOLOGY.md
2. socratic-roadmaps/01-GAP-MAP.md
3. socratic-roadmaps/phase-1-your-first-phase.md

Work through the Socratic questions by implementing working code.
Start by [starting condition]. End by verifying the Safety Gate.
```

**Google Antigravity:** Load the methodology as an Agent Skill. Dispatch an agent with the gap map and phase file in its workspace.

**Replit:** Paste a condensed version of all three files into your Agent prompt (keep under 400 lines total).

### 5. Review and repeat

Check the agent's output against the Validation Criteria in your phase file. Update the Gap Map with what now exists. Write the next phase. Repeat.

---

## The Six Question Types

Every question in the Forge follows one of six types. These are documented in detail in [`00-SOCRATIC-METHODOLOGY.md`](00-SOCRATIC-METHODOLOGY.md).

| Type | Purpose | Template |
|------|---------|----------|
| **Boundary** | Define the edges of the problem | "What must be true about X before Y can safely happen?" |
| **Inversion** | Think like an attacker/adversary | "If you wanted to break this system, what would you exploit?" |
| **Constraint Discovery** | Find limits the spec didn't mention | "What are the costs and benefits of approach A vs. B?" |
| **Precedent** | Learn from existing code patterns | "Module X already solves a similar problem. What pattern did it use?" |
| **Tension** | Navigate genuine tradeoffs | "Two legitimate needs conflict. How do you serve both?" |
| **cLaw Gate** | Non-negotiable safety review at end of every phase | "Review everything you've designed. Where could this cause harm?" |

The **cLaw Gate** is named after the Asimov's cLaws safety framework — an adaptation of Isaac Asimov's Three Laws of Robotics for AI agents with real-world agency. The Forge was developed alongside [Agent Friday](https://github.com/FutureSpeak-AI/agent-friday), an AGI operating system where these laws are cryptographically enforced at runtime. The same first-principles safety reasoning is baked into the development methodology itself: every phase must pass a safety review rooted in the project's deepest values before it ships. See the [methodology file](00-SOCRATIC-METHODOLOGY.md) for the full story and guidance on adapting the cLaw Gate to your project's domain.

**The Cardinal Rule: Never put the answer in the question.**

❌ "A dependency called 'co1ors' exists alongside 'colors'. The only difference is an L replaced with a 1. How do we prevent this?"

✅ "What properties of a package name, combined with its registry metadata, would give you confidence this is the package the developer intended — and not something else?"

---

## System Architecture

A complete Socratic Forge has six layers:

```
ORCHESTRATOR.md                    ← Your command center
    │
CLAUDE.md / AGENTS.md / replit.md  ← Project-level agent instructions
    │
┌───┴──────────────────────────────────────────┐
│  00-SOCRATIC-METHODOLOGY.md                  │  ← Loaded EVERY session
│  01-GAP-MAP.md                               │  ← Loaded EVERY session
│  Track-level overview files (per track)      │
│  Phase-level task files (per phase)          │  ← ONE loaded per session
└──────────────────────────────────────────────┘
```

Each session loads exactly **three files**: the methodology, the gap map, and one phase file. This keeps the agent's context focused (~400-500 lines total), leaving the vast majority of its context window free for code, reasoning, and tool use.

---

## Repo Structure

```
socratic-forge/
├── README.md                          ← You are here
├── 00-SOCRATIC-METHODOLOGY.md         ← The behavioral contract (generic, use as-is)
├── SOCRATIC-BUILD-METHOD.md           ← Full guide: how to build a Forge for any project
│
├── templates/                         ← Copy these into your project
│   ├── 00-SOCRATIC-METHODOLOGY.md     ← Same as root (convenient copy target)
│   ├── 01-GAP-MAP-TEMPLATE.md         ← Fill in for your codebase
│   ├── PHASE-TEMPLATE.md              ← Skeleton for a single phase
│   ├── TRACK-OVERVIEW-TEMPLATE.md     ← Skeleton for a track overview
│   ├── ORCHESTRATOR-TEMPLATE.md       ← Skeleton for the command center
│   ├── CLAUDE-MD-TEMPLATE.md          ← For Claude Code projects
│   ├── AGENTS-MD-TEMPLATE.md          ← For Google Antigravity projects
│   └── REPLIT-MD-TEMPLATE.md          ← For Replit projects
│
└── examples/                          ← A worked example (fictional SaaS app)
    ├── README.md                      ← Example project description
    ├── 01-GAP-MAP.md                  ← Example gap map
    ├── ORCHESTRATOR.md                ← Example orchestrator
    ├── Track-I-Auth-Fortress.md       ← Example track overview
    ├── Track-II-Data-Engine.md        ← Example track overview
    ├── track-1/
    │   ├── phase-1-auth-core.md       ← Complete example phase
    │   └── phase-2-rbac.md            ← Complete example phase
    └── track-2/
        └── phase-1-schema-design.md   ← Complete example phase
```

---

## Scaling

| Project Size | Tracks | Phases per Track | Orchestrator? | Time |
|-------------|--------|-----------------|---------------|------|
| Weekend hack | 1 | 2-3 | No | 1-2 days |
| Side project | 1-2 | 3-5 each | Optional | 1-3 weeks |
| Production app | 3-5 | 3-6 each | Yes | 1-3 months |
| Enterprise platform | 5-15 | 3-8 each | Essential | 3-12 months |

The method adapts because the **depth of your inquiry** adapts. A weekend project gets one Boundary question and one Safety Gate per phase. An enterprise build gets the full six-type treatment with inversions, precedents, tensions, and multi-layered validation criteria.

---

## Platform-Specific Notes

### Claude Code
The native home of the Forge. Place `CLAUDE.md` in your project root — Claude Code reads it automatically. Use the three-file launch prompts from your Orchestrator. Run parallel sessions on non-blocking tracks.

### Google Antigravity
Use `AGENTS.md` as your project identity file. Load the methodology as an Agent Skill for automatic inheritance. Use the Manager View (Mission Control) for parallel track execution. Map validation criteria to Antigravity's artifact system.

### Replit
Use `replit.md` with RulesSync for cross-project consistency. Front-load context into the Agent prompt (condensed methodology + gap map + phase questions). Let Agent 3's self-testing loop handle your safety gate assertions. Batch 2-3 sequential phases per session given the 200-minute autonomy window.

### Cursor / Windsurf / Others
Use `.cursorrules` or equivalent project-level config. The three-file pattern works in any agent that can read markdown files. Adapt the launch prompt format to your tool's conventions.

---

## Anti-Patterns

| Anti-Pattern | What Goes Wrong | Fix |
|-------------|----------------|-----|
| **Instruction disguised as question** | "Given that we need Redis here, what key schema?" — you already decided on Redis | Remove the answer. "This data is read 100x more than written. What caching strategy fits?" |
| **Kitchen sink phase** | Phase file over 200 lines, scope too broad | Split it. One coherent deliverable per phase. |
| **Stale gap map** | Agent builds on false assumptions about what exists | Update the gap map after every completed phase. |
| **Context overload** | Loading 5+ files degrades agent reasoning | Three files per session. Summarize cross-track context in the phase file. |
| **Skipped safety gate** | Issues compound across phases | Never skip. Safety gates exist because agent reasoning is good but not infallible. |

---

## Contributing

Improvements to the methodology, new templates, platform-specific adaptations, and example projects are welcome. If you build a Forge for your project and want to share the structure (not your proprietary code), open a PR to the `examples/` directory.

---

## License

MIT. Use this method however you want. Build something great.

---

*"The unexamined code is not worth shipping."*
